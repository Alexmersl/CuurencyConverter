package com.example.myfirstapponkotlin;

public class ConversionResult {
    private String conversion_result;
    public String getConversionResult(){
        return conversion_result;
    }
}
