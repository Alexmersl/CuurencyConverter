package com.example.myfirstapponkotlin

import android.widget.EditText
import com.example.myfirstapponkotlin.MainActivity.Companion.inAmount
import com.example.myfirstapponkotlin.MainActivity.Companion.inCurrency
import com.example.myfirstapponkotlin.MainActivity.Companion.outCurrency
import com.google.android.material.textfield.TextInputEditText

class FieldInput {

    companion object {
        fun inputAmount (editText: EditText) : String? = editText.text.toString()
        fun getInCurrency1(textInputEditText : TextInputEditText) : String? = textInputEditText.text.toString()
        fun getOutCurrency2(textInputEditText : TextInputEditText) : String? = textInputEditText.text.toString()
        fun getAmount(): String? = inAmount
        fun getInCurrency() : String? = inCurrency
        fun getOutCurrency() : String? = outCurrency
    }

}