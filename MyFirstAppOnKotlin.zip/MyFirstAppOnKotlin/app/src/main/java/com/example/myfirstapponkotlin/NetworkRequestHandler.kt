@file:Suppress("DEPRECATION")

package com.example.myfirstapponkotlin

import android.os.AsyncTask
import android.widget.TextView

object NetworkRequestHandler : AsyncTask<Void, Void, String>() {
    var res : String? = ""
    override fun doInBackground(vararg params: Void?): String {
        return HttpConnectionClass.getAmountResult()
    }

    override fun onPostExecute(result: String?) {
        super.onPostExecute(result)
        res = result
    }
}