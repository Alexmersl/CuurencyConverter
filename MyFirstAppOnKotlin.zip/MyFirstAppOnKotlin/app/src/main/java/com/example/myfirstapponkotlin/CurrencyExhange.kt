package com.example.myfirstapponkotlin

class CurrencyExhange {
    fun getValue() {

    }
    }
