package com.example.myfirstapponkotlin;

import java.util.Map;

public class CurrencyData {
    private Map<String, Double> conversion_rates;

    public Map<String, Double> getConversionRates() {
        return conversion_rates;
    }
}
